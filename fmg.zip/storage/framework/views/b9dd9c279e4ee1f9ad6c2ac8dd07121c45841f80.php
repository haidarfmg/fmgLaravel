<?php $__env->startSection('content'); ?>

        <h1 align="center">hello world</h1>
        <table class="table table-striped" width="100%">
            <tbody>
                <?php
                    // $productitem =$product;
                    ?>
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">name</th>
                          <th scope="col">price</th>
                          <th scope="col">edit</th>
                          <th scope="col">delete</th>
                        </tr>
                      </thead>
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($productitem->id > 0): ?>
                    <tr>
                        <td> <?php echo e($productitem->id); ?></td>
                        <td><?php echo e($productitem->name); ?></td>
                        <td><?php echo e($productitem->price); ?></td>
                        <td><a href="product/edit/<?php echo e($productitem->id); ?>">edit</a></td>
                        <td><a href="product/delete/<?php echo e($productitem->id); ?>">delete</a></td>
                    </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
<?php $__env->stopSection(); ?>















<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\haida\OneDrive\Desktop\fmglarravel\fmg\resources\views/product/view.blade.php ENDPATH**/ ?>