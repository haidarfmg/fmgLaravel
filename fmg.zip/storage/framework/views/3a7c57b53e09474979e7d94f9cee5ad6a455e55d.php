<?php $__env->startSection('content'); ?>
    <br>
    <h1 align="center">insert Product </h1>
    <br><br>
    <form  action="/credit/edit/<?php echo e($people->id); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        name : <input type="text" name="name" value="<?php echo e($people->name); ?> ">
        <br><br>
        number : <input type="text" name="number" value="<?php echo e($people->credit->number); ?>">
        <br><br>
         <input type="submit" name="submit" value="edit">
    </form>
    <?php $__env->stopSection(); ?>













<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\haida\OneDrive\Desktop\fmglarravel\fmg\resources\views/credit/edit.blade.php ENDPATH**/ ?>