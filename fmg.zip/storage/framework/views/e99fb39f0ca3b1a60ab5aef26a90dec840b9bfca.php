<?php $__env->startSection('content'); ?>
    <br>
    <h1 align="center">insert Product </h1>
    <br><br>
    <?php if(count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form  action="insertc" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="input-group mb-3">
            <div class="input-group mb-3">
            <label class="input-group-text" for="inputGroupFile02">name :</label>
            <input type="text" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" id="inputGroupFile02">
        </div>
        <div class="input-group mb-3">
            <label class="input-group-text" for="inputGroupFile02">credit number :</label>
            <input type="text" name="number" value="<?php echo e(old('number')); ?>" class="form-control <?php echo e($errors->has('number') ? ' is-invalid' : ''); ?>" id="inputGroupFile02">
        </div>
        <div class="input-group mb-3">
            <input class="btn btn-primary" type="submit" name="submit" value="insert">
        </div>

    </form>
    <?php $__env->stopSection(); ?>













<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\haida\OneDrive\Desktop\fmglarravel\fmg\resources\views/credit/insertc.blade.php ENDPATH**/ ?>