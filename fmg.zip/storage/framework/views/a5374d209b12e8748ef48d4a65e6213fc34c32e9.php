<?php echo e($slot); ?>

<?php /**PATH C:\Users\haida\OneDrive\Desktop\fmglarravel\fmg\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>