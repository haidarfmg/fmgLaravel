<?php $__env->startSection('content'); ?>
    <div class="text-center my-0">
        <h1>display  credits</h1>
        <table class="table table-striped" width="100%">
            <tbody>
                <?php
                    // $productitem =$product;
                    ?>
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">name</th>
                          <th scope="col">number</th>
                          <th scope="col">edit</th>
                          <th scope="col">delete</th>
                        </tr>
                      </thead>
                <?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $people1i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($people1i->id > 0): ?>
                    <tr>
                        <td> <?php echo e($people1i->id ); ?></td>
                        <td><?php echo e($people1i->name); ?></td>
                        <td><?php echo e(empty($people1i->credit['number']) ? 'N/A' : $people1i->credit['number']); ?></td>
                        <td><a href="credit/edit/<?php echo e($people1i->id); ?>">edit</a></td>
                        <td><a href="credit/delete/<?php echo e($people1i->id); ?>">delete</a></td>
                    </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\haida\OneDrive\Desktop\fmglarravel\fmg\resources\views/credit/displayc.blade.php ENDPATH**/ ?>