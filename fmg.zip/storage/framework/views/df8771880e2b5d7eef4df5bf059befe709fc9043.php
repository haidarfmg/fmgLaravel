
<br><br><br>
<h1 align="center">
    <?php echo e("id : ".$id); ?>

</h1>
<h1 align="center">
    <?php echo e("name : ".$name); ?>

</h1>
<h1 align="center">
    <?php echo e("age : ".$age); ?>

</h1>

<?php for($i=0; $i < 10; $i++): ?>
    <h1 align="center">
        <?php echo e($name); ?>

        <br>
    </h1>
<?php endfor; ?>
<?php /**PATH C:\Users\haida\OneDrive\Desktop\fmglarravel\fmg\resources\views/fmg.blade.php ENDPATH**/ ?>