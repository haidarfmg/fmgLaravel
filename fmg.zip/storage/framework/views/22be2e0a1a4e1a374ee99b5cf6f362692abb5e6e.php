<?php $__env->startSection('content'); ?>
    <br>
    <h1 align="center">insert Product </h1>
    <br><br>
    <form  action="/product/edit/<?php echo e($product->id); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        name : <input type="text" name="name" value="<?php echo e($product->name); ?> ">
        <br><br>
        price : <input type="text" name="price" value="<?php echo e($product->price); ?>">
        <br><br>
         <input type="submit" name="submit" value="edit">
    </form>
    <?php $__env->stopSection(); ?>













<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\haida\OneDrive\Desktop\fmglarravel\fmg\resources\views/product/edit.blade.php ENDPATH**/ ?>